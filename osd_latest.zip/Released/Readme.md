This folder contains Config Toll (OSD_Config.exe) and charsert (MinimOSD_2.4.1.2.mcm) for OSD. 

Also it contains sample TLOG file for testing needs.


Ready-to-flash HEX files of firmware are in "FW & Char" folder.

MinimOsd_Extra_Uni.[vers]DV-release.hex - main firmware

Character_Updater_FW.hex - utility tool to upload and check fonts if uploading via firmware fails.

All *.osd files are the samples of OSD screens
